#pragma once

#include "Vector2.h"

class Collider {
public:
    Vector2 size;
    Vector2 offset;
};